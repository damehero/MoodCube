import 'package:flutter/material.dart';
import 'home_page.dart';
import 'package:store_redirect/store_redirect.dart';
import 'package:flutter_appavailability/flutter_appavailability.dart';
import 'package:youtube_extractor/youtube_extractor.dart';

const URL = "https://google.com";

class Page2 extends StatefulWidget {
  @override
  Playlist createState() => Playlist("Playlist");
}

/**
 * what happens when the Playlist tab is open
 */
class Playlist extends State<Page2> {
  final String title;
  var extractor = YouTubeExtractor();

  Playlist(this.title);

  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: Scaffold(
        appBar: new AppBar(
          title: new Text(title),
          backgroundColor: Colors.green[900],
        ),
        backgroundColor: Color.fromRGBO(HomePageState.redCount,
            HomePageState.greenCount, HomePageState.blueCount, 1),
        body: Center(
          child: Container(
            child: new Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                new RaisedButton(
                  child: Image.asset('assets/images/HappyButton.png',
                      width: 100, height: 100),
                  onPressed: () {
                    AppAvailability.launchApp(
                            "spotify:artist:7IWshUcKfJyDWrbiF2XT8J")
                        .catchError(
                      (err) {
                        StoreRedirect.redirect(
                          androidAppId: "com.spotify.music",
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
