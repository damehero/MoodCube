#import <Flutter/Flutter.h>

@interface FlutterBluetoothSerialPlugin : NSObject<FlutterPlugin>
@end
