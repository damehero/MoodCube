import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:scoped_model/scoped_model.dart';


class BackgroundCollectingTask extends Model
{
  static BackgroundCollectingTask of(BuildContext context, {bool rebuildOnChange = false}) =>
      ScopedModel.of<BackgroundCollectingTask>(context, rebuildOnChange: rebuildOnChange);
  
  final BluetoothConnection _connection;
  List<int> _buffer = List<int>();


  bool inProgress;

  BackgroundCollectingTask._fromConnection(this._connection) {
    print("check");

    _connection.input.listen((data) {
      switch(data.toString())
      {
        case "0" : print("add red"); break;
        case "1" : print("add blue"); break;
        case "2" : print("add green"); break;
      }
    });
  }

  static Future<BackgroundCollectingTask> connect(BluetoothDevice server) async {
    final BluetoothConnection connection = await BluetoothConnection.toAddress(server.address);
    return BackgroundCollectingTask._fromConnection(connection);
  }

  void dispose() {
    _connection.dispose();
  }

  Future<void> start() async {
    inProgress = true;
    _buffer.clear();
    notifyListeners();
    _connection.output.add(ascii.encode('start'));
    await _connection.output.allSent;
  }

  Future<void> cancel() async {
    inProgress = false;
    notifyListeners();
    _connection.output.add(ascii.encode('stop'));
    await _connection.finish();
  }

  Future<void> pause() async {
    inProgress = false;
    notifyListeners();
    _connection.output.add(ascii.encode('stop'));
    await _connection.output.allSent;
  }

  Future<void> reasume() async {
    inProgress = true;
    notifyListeners();
    _connection.output.add(ascii.encode('start'));
    await _connection.output.allSent;
  }
}
