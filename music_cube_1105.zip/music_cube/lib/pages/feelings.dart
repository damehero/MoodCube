import 'package:flutter/material.dart';
import 'home_page.dart';
import 'dialogs.dart';

/**
 * what happens when the Feelings tab is open
 */

class Feelings extends StatelessWidget {
  final String title;
  bool tappedYes = false;

  Feelings(this.title);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(title),
        backgroundColor: Colors.red[900],
      ),
      backgroundColor: Color.fromRGBO(HomePageState.redCount,
          HomePageState.greenCount, HomePageState.blueCount, 1),
      body: new Container(
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            new RaisedButton(
              padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 24.0),
              child: Image.asset('assets/images/HappyButton.png',
                  width: 50, height: 50),
              onPressed: () {
                HomePageState.setGreen();
                print(HomePageState.redCount);
                print(HomePageState.blueCount);
              },
            ),
            new RaisedButton(
              padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 24.0),
              child: Image.asset('assets/images/SadButton.png',
                  width: 50, height: 50),
              onPressed: () {
                HomePageState.setBlue();
                print(HomePageState.redCount);
                print(HomePageState.greenCount);
              },
            ),
            new RaisedButton(
              padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 24.0),
              child: Image.asset('assets/images/AngryButton.png',
                  width: 50, height: 50),
              onPressed: () {
                HomePageState.setRed();
                print(HomePageState.greenCount);
                print(HomePageState.blueCount);
              },
            ),
            new RaisedButton(
              child: new Text("Reset"),
              color: Colors.white,
              onPressed: () {
                HomePageState.reset();
                print(HomePageState.redCount);
                print(HomePageState.greenCount);
                print(HomePageState.blueCount);
              },
            ),
          ],
        ),
      ),
    );
  }
}
