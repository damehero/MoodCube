import 'package:flutter/material.dart';
import 'home_page.dart';

/**
 * what happens when the Playlist tab is open
 */
class Playlist extends StatelessWidget {
  final String title;

  Playlist(this.title);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(title),
        backgroundColor: Colors.greenAccent[900],
      ),
      backgroundColor: Color.fromRGBO(HomePageState.redCount,
          HomePageState.greenCount, HomePageState.blueCount, 1),
      body: new Center(
        child: new Text(title),
      ),
    );
  }
}
