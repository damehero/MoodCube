import 'package:flutter/material.dart';
import 'home_page.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'dart:io';

import 'package:flutter_appavailability/flutter_appavailability.dart';

const URL = "https://google.com";

class Page2 extends StatefulWidget {
  @override
  Playlist createState() => Playlist("Playlist");
}

/**
 * what happens when the Playlist tab is open
 */
class Playlist extends State<Page2> {
  final String title;
  Map<String, String> installedApps;

  Playlist(this.title);

  @override
  void initState() {
    super.initState();
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> getApps() async {
    Map<String, String> _installedApps;

    if (Platform.isAndroid) {
      print(await AppAvailability.checkAvailability(
          "spotify:playlist:3topCLyEdnUhxCvSIIPOHz"));
      // Returns: Map<String, String>{app_name: Chrome, package_name: com.android.chrome, versionCode: null, version_name: 55.0.2883.91}

      print(await AppAvailability.isAppEnabled(
          "spotify:playlist:3topCLyEdnUhxCvSIIPOHz"));
      // Returns: true

    }
    setState(() {
      installedApps = _installedApps;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (installedApps == null) getApps();

    return new Scaffold(
      appBar: new AppBar(
        title: new Text(title),
        backgroundColor: Colors.green[900],
      ),
      backgroundColor: Color.fromRGBO(HomePageState.redCount,
          HomePageState.greenCount, HomePageState.blueCount, 1),
      body: Center(
        child: Container(
          child: new Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              new RaisedButton(
                  child: Image.asset('assets/images/HappyButton.png',
                      width: 100, height: 100),
                  onPressed: () {
                    AppAvailability.launchApp(
                            "spotify:playlist:3topCLyEdnUhxCvSIIPOHz")
                        .catchError((err) {
                      Scaffold.of(context).showSnackBar(
                          SnackBar(content: Text("App not found!")));
                      print(err);
                    });
                  }),
            ],
          ),
        ),
      ),
    );
  }
}
