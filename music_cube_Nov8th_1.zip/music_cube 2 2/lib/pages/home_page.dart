import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'feelings.dart';
import 'playlist.dart';
import 'settings.dart';

class HomePage extends StatefulWidget {
  @override
  HomePageState createState() => new HomePageState();
}

class HomePageState extends State<HomePage> {
  String currentProfilePic =
      "https://github.com/libgit2/libgit2sharp/raw/master/square-logo.png";
  String otherProfilePic =
      "https://github.com/libgit2/libgit2sharp/raw/master/square-logo.png";
  static int redCount = 255;
  static int greenCount = 255;
  static int blueCount = 255;
  static int change = 5;
  static List<int> result = [0, 0, 0];
  static Color color =
      Color.fromRGBO(255 - redCount, 255 - greenCount, 255 - blueCount, 1);

  static Color getColor() {
    return color;
  }

  static void setColor() {
    color =
        Color.fromRGBO(255 - redCount, 255 - greenCount, 255 - blueCount, 1);
  }

  static int getRed() {
    return redCount;
  }

  static void setRed() {
    if (greenCount >= change) greenCount -= change;
    if (blueCount >= change) blueCount -= change;
  }

  static int getGreen() {
    return greenCount;
  }

  static void setGreen() {
    if (redCount >= change) redCount -= change;
    if (blueCount >= change) blueCount -= change;
  }

  static int getBlue() {
    return blueCount;
  }

  static void setBlue() {
    if (redCount >= change) redCount -= change;
    if (greenCount >= change) greenCount -= change;
  }

  static void reset() {
    redCount = 255;
    greenCount = 255;
    blueCount = 255;
    result = [0, 0, 0];
  }

  @override
  void initState() {
    super.initState();
    _loadCounter_R();
    _loadCounter_G();
    _loadCounter_B();
  }

  static addIntToR() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt('counter_R', redCount);
  }

  static addIntToG() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt('counter_G', greenCount);
  }

  static addIntToB() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt('counter_B', blueCount);
  }

  static void update() {
    addIntToB();
    addIntToR();
    addIntToG();
  }

  _loadCounter_R() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      redCount = (prefs.getInt('counter_R') ?? 255);
    });
  }

  _loadCounter_G() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      greenCount = (prefs.getInt('counter_G') ?? 255);
    });
  }

  _loadCounter_B() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      blueCount = (prefs.getInt('counter_B') ?? 255);
    });
  }

  void switchAccounts() {
    String picBackup = currentProfilePic;
    this.setState(() {
      currentProfilePic = otherProfilePic;
      otherProfilePic = picBackup;
    });
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(
          "Hello",
          style: TextStyle(
              color: Color.fromRGBO(
                  255 - redCount, 255 - greenCount, 255 - blueCount, 1)),
        ),
        backgroundColor: Color.fromRGBO(redCount, greenCount, blueCount, 1),
        //elevation: 0.0,
        leading: Builder(
          builder: (context) => new FlatButton(
            child:
                Image.asset('assets/images/Star.png', width: 100, height: 100),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
      ),
      // elevation hides drop shadow of appbar

      drawer: new Drawer(
        child: new ListView(
          children: <Widget>[
            new UserAccountsDrawerHeader(
              //accountName: new Text("Soyon"),
              //accountEmail: new Text(''),
              currentAccountPicture: new GestureDetector(
                child: new CircleAvatar(
                  backgroundImage: new NetworkImage(currentProfilePic),
                ),
                onTap: () => print("This is your current account."),
              ),
              otherAccountsPictures: <Widget>[],
              decoration: new BoxDecoration(
                  image: new DecorationImage(
                      image: new NetworkImage(
                          "https://github.com/libgit2/libgit2sharp/raw/master/square-logo.png"),
                      fit: BoxFit.fill)),
            ),
            new ListTile(
                title: new Text("Feelings"),
                trailing: new Icon(Icons.arrow_right),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context, MaterialPageRoute(builder: (c) => Page1()));
                }),
            new Divider(),
            new ListTile(
                title: new Text("My Playlist"),
                trailing: new Icon(Icons.arrow_right),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context, MaterialPageRoute(builder: (c) => Page2()));
                }),
            new Divider(),
            new ListTile(
                title: new Text("Settings"),
                trailing: new Icon(Icons.arrow_right),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context, MaterialPageRoute(builder: (c) => Page3()));
                }),
            new Divider(),
            new ListTile(
              title: new Text("Cancel"),
              trailing: new Icon(Icons.cancel),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
      backgroundColor: Color.fromRGBO(redCount, greenCount, blueCount, 1),
      body: Center(
        child: Container(
          child: new Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[Image.asset('assets/images/MainPage.png')],
          ),
        ),
      ),
    );
  }
}
