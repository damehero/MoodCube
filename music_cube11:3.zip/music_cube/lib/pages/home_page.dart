import 'package:flutter/material.dart';

import 'page.dart';

import 'playlists.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => new _HomePageState();
}

class _HomePageState extends State<HomePage> {

  String currentProfilePic = "https://picsum.photos/id/9/250/250";

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar:new AppBar(title: new Text("Music Machine"), backgroundColor: Colors.grey[900], elevation: 0.0, leading: Builder(
          builder: (context) => IconButton(
            icon: new Icon(Icons.menu), // leading widget for icon changes
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),), // elevation hides drop shadow of appbar
        drawer: new Drawer(
          child: new ListView(
            children: <Widget>[
              new UserAccountsDrawerHeader(
                accountEmail: new Text("daman.heer0@gmail.com"),
                accountName: new Text("Daman Heer"),
                currentAccountPicture: new GestureDetector(
                  child: new CircleAvatar(
                    backgroundImage: new NetworkImage(currentProfilePic),
                  ),
                  onTap: () => print("This is your current account."),
                ),

                decoration: new BoxDecoration(
                    image: new DecorationImage(
                        image: new NetworkImage("https://static.scientificamerican.com/sciam/cache/file/BCC3BD1E-5DC0-4843-A841706AE575C694.jpg"),
                        fit: BoxFit.fill
                    )
                ),
              ),
              new ListTile(
                  title: new Text("Playlists"),
                  trailing: new Icon(Icons.library_music),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Playlist("Playlists")));
                  }
              ),
              new Divider(),
              new ListTile(
                  title: new Text("Statistics"),
                  trailing: new Icon(Icons.arrow_right),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Page("Stats")));
                  }
              ),
              new Divider(),
              new ListTile(
                  title: new Text("History"),
                  trailing: new Icon(Icons.arrow_right),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Page("History")));
                  }
              ),
              new Divider(),
              new ListTile(
                title: new Text("Cancel"),
                trailing: new Icon(Icons.cancel),
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
        body: Center(
          child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/images/cat.png"),
              fit: BoxFit.cover,
            )
          ),
          child: Align(
            alignment: FractionalOffset(100.5, 0.1), // positioning text
            child: Text("How are you feeling today?",
                style: new TextStyle(
                    fontSize: 35.0,
                    color: Colors.white),
            ),
        )
        )
        )
    );
  }
}