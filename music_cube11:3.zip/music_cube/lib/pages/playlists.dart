import 'package:flutter/material.dart';

class Playlist extends StatelessWidget {

  final String title;

  Playlist(this.title);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text("Hello"), backgroundColor: Colors.blue[800],),
      body: new Center(
        child: Container(
          decoration: BoxDecoration(
            color: Colors.grey
          ),
    child: FlatButton.icon(
    color: Colors.blue,
    icon: Icon(Icons.music_note), //`Icon` to display
    label: Text('New Playlist'), //`Text` to display
    onPressed: () {
    }
        )
      ),
      )
    );
  }
}