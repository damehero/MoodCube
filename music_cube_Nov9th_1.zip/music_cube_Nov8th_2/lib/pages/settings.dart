import 'package:flutter/material.dart';
import 'home_page.dart';

class Page3 extends StatefulWidget {
  @override
  Settings createState() => Settings("Settings");
}

/**
 * what happens when the Settings tab is open
 */

class Settings extends State<Page3> {
  final String title;

  Settings(this.title);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(title),
        backgroundColor: Colors.blueAccent[900],
      ),
      backgroundColor: Color.fromRGBO(HomePageState.redCount,
          HomePageState.greenCount, HomePageState.blueCount, 1),
      body: new Center(
        child: new Text(title),
      ),
    );
  }
}
