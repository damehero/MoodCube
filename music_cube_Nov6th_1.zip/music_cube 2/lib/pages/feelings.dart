import 'package:flutter/material.dart';
import 'home_page.dart';
import 'dialogs.dart';

/**
 * what happens when the Feelings tab is open
 */

class Feelings extends StatelessWidget {
  final String title;
  bool tappedYes = false;

  Feelings(this.title);

  Dialogs dialogs = new Dialogs();

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(title),
        backgroundColor: Colors.red[900],
      ),
      backgroundColor: Color.fromRGBO(HomePageState.redCount,
          HomePageState.greenCount, HomePageState.blueCount, 1),
      body: Center(
        child: Container(
          child: new Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              new RaisedButton(
                child: Image.asset('assets/images/HappyButton.png',
                    width: 100, height: 100),
                onPressed: () {
                  HomePageState.setGreen();
                  HomePageState.result[1]++;
                  print('red:');
                  print(HomePageState.redCount);
                  print('blue:');
                  print(HomePageState.blueCount);
                  HomePageState.update();
                },
              ),
              new RaisedButton(
                child: Image.asset('assets/images/SadButton.png',
                    width: 100, height: 100),
                onPressed: () {
                  HomePageState.setBlue();
                  HomePageState.result[2]++;
                  print('red');
                  print(HomePageState.redCount);
                  print('green');
                  print(HomePageState.greenCount);
                  HomePageState.update();
                },
              ),
              new RaisedButton(
                child: Image.asset('assets/images/AngryButton.png',
                    width: 100, height: 100),
                onPressed: () {
                  HomePageState.setRed();
                  HomePageState.result[0]++;
                  print('green');
                  print(HomePageState.greenCount);
                  print('blue');
                  print(HomePageState.blueCount);
                  HomePageState.update();
                },
              ),
              new RaisedButton(
                  child: new Text("Statistics"),
                  color: Colors.white,
                  onPressed: () {
                    HomePageState.update();
                    dialogs.information(
                        context,
                        "Your Anger/Happiness/Sadness Levels are: ",
                        HomePageState.result.toString());
                  }),
              new RaisedButton(
                child: new Text("Reset"),
                color: Colors.white,
                onPressed: () {
                  HomePageState.reset();
                  print(HomePageState.redCount);
                  print(HomePageState.greenCount);
                  print(HomePageState.blueCount);
                  HomePageState.update();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
